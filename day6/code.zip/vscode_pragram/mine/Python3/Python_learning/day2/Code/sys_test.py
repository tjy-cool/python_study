#!/user/bin/env python
# file_name: sys.test.py

import sys
print(sys.path)

print(sys.argv)
print(sys.argv[0])
print(sys.argv[1])
print(sys.argv[2])
print(sys.argv[3])
